DROP USER 'CCAdmin'@'localhost';
DROP USER 'CCAdmin'@'127.0.0.1';
DROP USER 'CCAdmin'@'::1';

DROP USER 'Werknemer'@'localhost';
DROP USER 'Werknemer'@'127.0.0.1';
DROP USER 'Werknemer'@'::1';

DROP USER 'Klant'@'localhost';
DROP USER 'Klant'@'127.0.0.1';
DROP USER 'Klant'@'::1';

DROP DATABASE coronacompleet;